﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cálculo_IMC
{
    public partial class Form1 : Form
    {
        Double Peso, Altura, Imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TxtAltura.Text, out Altura))
            { 
                MessageBox.Show("Número Inválido");
                txtPeso.Focus();
            }
            if (Altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero!");
                txtPeso.Focus();
            }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            Imc = Peso / Math.Pow(Altura, 2);
            Imc = Math.Round(Imc, 1);

            if (Imc < 18.5)
                MessageBox.Show("Seu IMC é de " + Imc.ToString("N2")+" e sua classificação é 'Magreza'");
            else

                if (Imc <= 24.9)
                MessageBox.Show("Seu IMC é de " + Imc.ToString("N2") + " e sua classificação é 'Normal'");
            else

                    if (Imc <= 39.9)
                MessageBox.Show("Seu IMC é de " + Imc.ToString("N2") + " e sua classificação é 'Sobrepeso'");
            else

                MessageBox.Show("Seu IMC é de " + Imc.ToString("N2") + " e sua classificação é 'Obesidade Grave'");
        }

        private void TxtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out Peso))
            {
                MessageBox.Show("Número Inválido");
                txtPeso.Focus();
            }
             if (Peso <= 0)
            {
                MessageBox.Show("Peso deve ser maior que zero!");
                txtPeso.Focus();
            }   

        }
    }
}
