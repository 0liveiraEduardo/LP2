﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraSimples
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; 

        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("Número 1 inválido!");

            }
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido!");

            }

        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) && (double.TryParse(txtNum2.Text, out numero2)))
            {

                resultado = numero1 - numero2;
                txtNum3.Text = resultado.ToString();

            }
            else
                MessageBox.Show("Números Inválidos");
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) && (double.TryParse(txtNum2.Text, out numero2)))
            {

                resultado = numero1 * numero2;
                txtNum3.Text = resultado.ToString();

            }
            else
                MessageBox.Show("Números Inválidos");
        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) && (double.TryParse(txtNum2.Text, out numero2)))
            {

                resultado = numero1 / numero2;
                txtNum3.Text = resultado.ToString();

            }
            else
                MessageBox.Show("Números Inválidos");

            if (numero2 == 0)
                MessageBox.Show("Não dá para dividir por 0");
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtNum3.Clear();

        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            // txtNum3.Text = txNum1.Text + txNum2.Text;

            if (double.TryParse(txtNum1.Text, out numero1) && (double.TryParse(txtNum2.Text, out numero2)))
            {

                resultado = numero1 + numero2;
                txtNum3.Text = resultado.ToString();

            }
            else
                MessageBox.Show("Números Inválidos");
        }
    }
}
