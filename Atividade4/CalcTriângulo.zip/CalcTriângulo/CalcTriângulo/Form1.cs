﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcTriângulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;

        private void txt2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txt2.Text, out LadoB))
                MessageBox.Show("Insira um valor válido");
        }

        private void txt3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txt3.Text, out LadoC))
                MessageBox.Show("Insira um valor válido");
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (LadoA < (LadoB + LadoC) && LadoA > Math.Abs(LadoB - LadoC) && LadoB < (LadoA + LadoC) && LadoB > Math.Abs(LadoA - LadoC) && LadoC < (LadoA + LadoB) && LadoC > Math.Abs(LadoA - LadoB))
            {
                if(LadoA == LadoB && LadoB == LadoC)
                    MessageBox.Show("Triângulo Equilátero");
                else
                    if(LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                    MessageBox.Show("Triângulo Isóceles");
                    else
                        if(LadoA != LadoB && LadoB != LadoC)
                        MessageBox.Show("Triângulo Escaleno");

            } 
            else
                MessageBox.Show("Não é um triângulo");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txt1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txt1.Text, out LadoA))
                MessageBox.Show("Insira um valor válido");
        }
    }
}
