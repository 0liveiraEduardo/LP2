﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PCotacao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double[,] MatrizN = new double[10, 3];
            double media1 = 0, media2 = 0;
            string auxiliar;
          
            listDados.Items.Clear();

            for (var i = 0; i < 10; i++)
            {

                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Notebook " + (i + 1) + " Loja " + (j + 1), " Media ");

                    if (!double.TryParse(auxiliar, out MatrizN[i, j]))
                    {
                        MessageBox.Show("Valor inválido");
                        i--;
                    }
                    else
                    {
                        media1 += MatrizN[i, j];
                    }
                    if (j == 0)
                    {
                        media1 += MatrizN[i, j];
                    }
                    else
                    {
                        media2 += MatrizN[i, j];
                    }

                    {
                        listDados.Items.Add("Notebook " + (i + 1) + " Loja 1: " + (j + 1) + media2.ToString("N2"));
                    }

                }

            }
        }
    }
}
