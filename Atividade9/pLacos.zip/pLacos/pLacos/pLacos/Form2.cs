﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pLacos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtN_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            int n;
            double h = 1.0;

            if (!(int.TryParse(txtN.Text, out n)))
            {
                MessageBox.Show("Somente número");
                txtN.Focus();
            }
            else if (n == 0)
            {
                MessageBox.Show("Insira um valor diferente de zero");
            }
            else
            {
                for (var i = 0; i < n; i++)
                {
                    h += 1.0f / (i + 2);
                }
                MessageBox.Show("O número gerado foi H =  " + h.ToString());
            }
        }
    }
}
