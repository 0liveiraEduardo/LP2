﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pLacos
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            string texto = Rich1.Text;
            int cont = 0;

            foreach (char c in texto)
            {
                if (char.IsWhiteSpace(c))
                {
                    cont++;
                }
            }
            MessageBox.Show("Nº espaços em branco: " + cont.ToString());
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            char letraAnterior = '\0';
            int numPares = 0;
            
            for (var i = 0; i < Rich1.Text.Length; i++)
            {
                if (Rich1.Text[i] == letraAnterior)
                    numPares += 1;

                letraAnterior = Rich1.Text[i];
            }

            MessageBox.Show("Nº pares de letras: " + numPares.ToString());
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            int i = 0;
            int cont = 0;
            string texto = Rich1.Text;

            while (i < Rich1.Text.Length)
            {
                if (texto[i] == 'r' || texto[i] == 'R')
                {
                    cont++;
                }
                i++;

            }

            MessageBox.Show("Nº vezes que aparece r ou R: " + cont.ToString());
        }



    }
}
