﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio4 : Form
    {

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Cont = 0;

            for (int i = 0; i < RichBox1.Text.Length; i++)
            {
                if (Char.IsNumber(RichBox1.Text[i]))                
                {
                    Cont++;

                }
            }

            MessageBox.Show(Cont.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string EmBranco = RichBox1.Text;

            int cont = 0;

            int i = 0;

            while ( i < RichBox1.Text.Length)
                {
                if (Char.IsWhiteSpace(RichBox1.Text[i]))
                    break;

                else
                {
                    cont++;
                    i++;
                }
                
                }
            cont += 1;
            MessageBox.Show(cont.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach (char c in RichBox1.Text)
            {
                if (Char.IsLetter(c))
                { 
                    cont++;
                }
                
            }

            MessageBox.Show(cont.ToString());
        }
    }
}
